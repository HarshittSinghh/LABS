public class NoSuchMethod {

    public static void main(String[] args) {

        class MyClass {
            public void existingMethod(String name) {
                System.out.println("Hello, " + name + "!");
            }
        }

        try {
            MyClass obj = new MyClass();
            obj.existingMethod("rohan");
            obj.nonExistentMethod("sreeja");
        } catch (NoSuchMethodException e) {
            System.out.println("Error: Method not found - " + e.getMessage());
    }
    }
}